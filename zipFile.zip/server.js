// server.js — SmartResumeFix (Razorpay + OpenAI + PDF generation)
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import Razorpay from 'razorpay';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import puppeteer from 'puppeteer';
import multer from 'multer';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '1mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Env vars (set these in Replit Secrets)
const {
  RAZORPAY_KEY_ID,
  RAZORPAY_KEY_SECRET,
  OPENAI_API_KEY,
  HOST_URL,
  EMAIL_SMTP_HOST,
  EMAIL_SMTP_PORT,
  EMAIL_SMTP_USER,
  EMAIL_SMTP_PASS,
  DELIVERY_EMAIL_FROM
} = process.env;

if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
  console.warn('WARNING: Razorpay keys not set. Payment will fail until you add keys.');
}

const razorpay = new Razorpay({
  key_id: RAZORPAY_KEY_ID || '',
  key_secret: RAZORPAY_KEY_SECRET || ''
});

// Storage for upload (if using file upload)
const upload = multer({ dest: 'uploads/' });

/* ========== Utilities ========== */
function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}
ensureDir('resumes');

async function callOpenAI(resumeText, resumeType = 'Modern Professional', targetRole = '') {
  // Use OpenAI chat completion
  const system = `You are an expert resume writer and HR reviewer with 10+ years experience. Improve resumes for job applications focusing on clarity, ATS optimization, strong action verbs, and concise formatting. Keep dates and job history intact. Provide sections: NAME:, CONTACT:, SUMMARY:, EXPERIENCE:, EDUCATION:, SKILLS:.`;
  const userPrompt = `Format type: ${resumeType}\nTarget role: ${targetRole}\n\nResume text:\n${resumeText}\n\nOutput as plain text with headings labeled NAME:, CONTACT:, SUMMARY:, EXPERIENCE:, EDUCATION:, SKILLS:.`;
  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${OPENAI_API_KEY}` },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 1200,
      temperature: 0.2
    })
  });
  const data = await resp.json();
  if (!data || !data.choices || !data.choices[0]) {
    throw new Error('No response from OpenAI');
  }
  return data.choices[0].message.content;
}

function renderHtmlFromAiText(aiText) {
  // aiText expected to include labeled sections; we'll do a simple parse
  const getSection = (label) => {
    const re = new RegExp(`${label}:[\\s\\S]*?(?=\\n[A-Z]+:|$)`, 'i');
    const match = aiText.match(re);
    return match ? match[0].replace(new RegExp(`${label}:`, 'i'), '').trim() : '';
  };
  const name = getSection('NAME') || 'Applicant';
  const contact = getSection('CONTACT') || '';
  const summary = getSection('SUMMARY') || '';
  const experience = getSection('EXPERIENCE') || '';
  const education = getSection('EDUCATION') || '';
  const skills = getSection('SKILLS') || '';

  return `
  <!doctype html>
  <html>
  <head>
    <meta charset="utf-8"/>
    <title>${name} - Resume</title>
    <style>
      body{font-family:Arial,Helvetica,sans-serif; max-width:800px; margin:24px auto; color:#111}
      h1{font-size:20px;margin:0}
      .contact{margin-bottom:14px;color:#555}
      .section{margin-top:12px}
      .section h2{font-size:14px;border-bottom:1px solid #eee;padding-bottom:6px;color:#333}
      .bullet{margin-left:18px}
      pre{white-space:pre-wrap;font-family:inherit}
    </style>
  </head>
  <body>
    <h1>${name}</h1>
    <div class="contact">${contact}</div>
    <div class="section"><h2>Professional Summary</h2><pre>${summary}</pre></div>
    <div class="section"><h2>Experience</h2><pre>${experience}</pre></div>
    <div class="section"><h2>Education</h2><pre>${education}</pre></div>
    <div class="section"><h2>Skills</h2><pre>${skills}</pre></div>
  </body>
  </html>
  `;
}

async function htmlToPdfBuffer(html) {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox','--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });
  const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '20mm', bottom: '20mm' } });
  await browser.close();
  return pdfBuffer;
}

/* ========== Endpoints ========== */

// Health
app.get('/health', (req, res) => res.json({ ok: true }));

// Create a Razorpay order (client will call this to open checkout)
app.post('/api/create-order', async (req, res) => {
  try {
    const { amount_in_paise = 4900 } = req.body;
    const options = { amount: amount_in_paise, currency: 'INR', receipt: `srfix_${Date.now()}`, payment_capture: 1 };
    const order = await razorpay.orders.create(options);
    res.json({ success: true, order });
  } catch (err) {
    console.error('create-order error', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Razorpay webhook endpoint — configure this URL in Razorpay Dashboard
app.post('/webhook/razorpay', bodyParser.json({ type: '*/*' }), async (req, res) => {
  try {
    const payload = req.body;
    if (payload.event === 'payment.captured' && payload.payload && payload.payload.payment && payload.payload.payment.entity) {
      const payment = payload.payload.payment.entity;
      console.log('Payment captured:', payment.id, payment.amount);
    }
    res.status(200).send('ok');
  } catch (err) {
    console.error('webhook error', err);
    res.status(500).send('error');
  }
});

// Generate resume endpoint (client calls after receiving payment success client-side)
app.post('/api/generate', upload.none(), async (req, res) => {
  try {
    const { provider, payment_id, order_id, resume_text, resume_type = 'Modern Professional', email, name, target_role } = req.body;
    if (!payment_id || !resume_text) return res.status(400).json({ success: false, error: 'Missing payment_id or resume_text' });

    // Verify payment with Razorpay API
    let verified = false;
    try {
      const url = `https://api.razorpay.com/v1/payments/${payment_id}`;
      const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString('base64');
      const r = await fetch(url, { headers: { Authorization: `Basic ${auth}` } });
      const j = await r.json();
      if (j && (j.status === 'captured' || j.status === 'authorized')) verified = true;
    } catch (err) {
      console.error('payment verify error', err);
    }
    if (!verified) return res.status(400).json({ success: false, error: 'Payment not verified' });

    // Call OpenAI to improve the resume
    const aiText = await callOpenAI(resume_text, resume_type, target_role || '');

    // Render HTML and generate PDF
    const html = renderHtmlFromAiText(aiText);
    const pdfBuffer = await htmlToPdfBuffer(html);

    // Store PDF on server
    const fileName = `${Date.now()}_${uuidv4()}.pdf`;
    const filePath = path.join('resumes', fileName);
    fs.writeFileSync(filePath, pdfBuffer);

    // Optional: send email with attachment (if SMTP configured)
    if (EMAIL_SMTP_HOST && EMAIL_SMTP_USER && EMAIL_SMTP_PASS && email) {
      const transporter = nodemailer.createTransport({
        host: EMAIL_SMTP_HOST,
        port: Number(EMAIL_SMTP_PORT) || 587,
        secure: false,
        auth: { user: EMAIL_SMTP_USER, pass: EMAIL_SMTP_PASS }
      });
      const mailOptions = {
        from: DELIVERY_EMAIL_FROM || EMAIL_SMTP_USER,
        to: email,
        subject: 'Your Improved Resume — SmartResumeFix',
        text: 'Thanks for your order. Your improved resume is attached.',
        attachments: [{ filename: 'resume.pdf', path: filePath }]
      };
      transporter.sendMail(mailOptions).catch(err => console.error('email send error', err));
    }

    const downloadUrl = `${HOST_URL.replace(/\/$/, '')}/download/${fileName}`;
    res.json({ success: true, downloadUrl });

  } catch (err) {
    console.error('generate error', err);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});

// Serve generated resumes
app.get('/download/:file', (req, res) => {
  const file = path.join('resumes', req.params.file);
  if (fs.existsSync(file)) {
    res.download(file);
  } else res.status(404).send('Not found');
});

// Start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`SmartResumeFix backend running on port ${PORT}`));